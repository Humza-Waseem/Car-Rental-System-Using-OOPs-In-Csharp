﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.DL;
using ConsoleApp1.UI;
using ConsoleApp1.BL;

using System.IO;



namespace ConsoleApp1
{
    class PersonBL
    {
        protected string name;
        protected string password;
        protected string role;

        //    public  List<PersonBL> persons;
        public string getUserName()
        {
            return name;
        }
        public string getRole()
        {
            return role;
        }
        public string getPassword()
        {
            return password;
        }

        public  virtual void ViewAllCostumers()
        {
            Console.WriteLine("User names\t\tUser Roles \t\tPasswords ");
            Console.WriteLine("_________\t\t__________\t\t________");

            int i = 1;
            foreach (PersonBL p in PersonDL.persons)
            {
                Console.WriteLine(i + "." + p.getUserName() + "\t\t\t" + p.getRole() + "\t\t\t" + p.getPassword());
                i++;
            }
        }
        public virtual bool isCarNameAvailable(string name)
        {


            foreach (CarBL car in CarDL.listOfCars)
            {
                if (name != car.getCarName())
                {
                    continue;
                }
                else if (name == car.getCarName())
                {
                    Console.WriteLine("CAR: {0} is AVAILABLE for PRICE: {1} for 1 DAY RENT and COLOR is :{2}", car.getCarName(), car.getPrice(), car.getColorCar());
                    Console.ReadKey();
                    return true;
                    
                }
            }
            return false;
        }
        public virtual double GetCarPrice(string name)
        {


            foreach (CarBL car in CarDL.listOfCars)
            {
                if (name != car.getCarName())
                {
                    continue;
                }
                else if (name == car.getCarName())
                {
                    Console.WriteLine("CAR: {0} is AVAILABLE for PRICE: {1} for 1 DAY RENT", car.getCarName(), car.getPrice());
                    Console.ReadKey();
                 
                    return car.getPrice();
                }
            }
            return 0;
        }


        public virtual void headerForViewAllCars()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("         *********************************************************");
            Console.WriteLine("         *                                                       *");
            Console.WriteLine("         *       _____ _              _____ _____ _____ _____    *");
            Console.WriteLine("         *      |  |  |_|___ _ _ _   |     |  _  | __  |   __|   *");
            Console.WriteLine("         *      |  |  | | -_| | | |  |   --|     |    -|__   |   *");
            Console.WriteLine("         *       !___/|_|___|_____|  |_____|__|__|__|__|_____|   *");
            Console.WriteLine("         *                                                       *");
            Console.WriteLine("         *********************************************************");
            Console.ForegroundColor = ConsoleColor.Magenta;
        }
        public  virtual void viewAllCars()
        {
           
           
            Console.WriteLine("Car name\t\tCar Company\t\tCar Price\t\tCar Color");
            Console.WriteLine("_________\t\t___________\t\t_________\t\t________");

            int i = 1;
            foreach(CarBL car in CarDL.listOfCars)
            {
                Console.WriteLine(i+"."+car.getCarName()+"\t\t\t" + car.getCompanyName()+"\t\t\t"  + car.getPrice()+"\t\t\t"  + car.getColorCar());
                i++;
            }


        }

        public void  setPersonName(string name)
        {
            this.name = name;
        }
        public PersonBL()
        {

        }
       
          
        
        public PersonBL(string name)
        {
            this.name = name;
        }
        //for taking input without role
        public PersonBL(string name, string password) : this(name)
        {

            this.password = password;

        }
        //for taking input with role
        public PersonBL(string name, string password, string role) : this(name, password)
        {

            this.role = role;

        }

        public static bool isUserNameAvailable(string UserName)
        {
            foreach (PersonBL p in PersonDL.persons)
            {
                if (UserName != p.name)
                {
                    continue;                    
                }
                else if (UserName == p.name)
                {
                    return true;
                }

            }
            return false;


        }
        public static void PRintList()
        {
            foreach (PersonBL p in PersonDL.persons)
            {
                Console.WriteLine(p.name + " " + p.role + " " + p.password);
            }
        }
        public static string checkUserRole(string name, string password)
        {

            string userRole;
            for (int i = 0; i < PersonDL.persons.Count; i++)
            {
                if (name == PersonDL.persons[i].name && password == PersonDL.persons[i].password)
                {
                    userRole = PersonDL.persons[i].role;
                    return userRole;
                }

            }
            return null;
        }
     




        public static string  GetUserRole(PersonBL p)
        {
            if (p.name != null && p.password != null)
            {
                if (PersonDL.persons.Count > 0)
                {
                    string userRole = PersonBL.checkUserRole(p.name, p.password);
                    return userRole;

                  
                }
            }
            return null;
        }
        public static bool SetUserRole(string userRole, PersonBL p)
        {
            if (p.name != null && p.password != null && userRole != null)
            {
                return true;
            }
            return false;
        }
               


        

      
        //this is a common fuction for both admin and costumer
        public virtual void checkAvailablity()
        {

        }
        //this is a common fuction for both admin and costumer
        public virtual void checkPrice()
        {

        }
        public static  PersonBL setUserRole(string userRole)
        {
           if(userRole == "admin " || userRole == "ADMIN " ||userRole == "Admin " )
                    
           {
                AdminBL a = new AdminBL(userRole);
                return a;

           }
            if (userRole == "costumer " || userRole == "COSTUMER " || userRole == "Admin")
            {
                CostumerBL c = new CostumerBL(userRole);
                return c;
            }
                return null;
        }
     
             



    }
}


