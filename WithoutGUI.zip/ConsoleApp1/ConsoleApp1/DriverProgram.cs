﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;
using ConsoleApp1.DL;
using ConsoleApp1.UI;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Here are the set of paths for storing data in a file
            string reviewsPath = "E:\\OOPlab\\OOPProjectBusinessApplication\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\reviews.txt";
            string carsPath = "E:\\OOPlab\\OOPProjectBusinessApplication\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\cars.txt";
            string usersPath = "E:\\OOPlab\\OOPProjectBusinessApplication\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\Users.txt";
            string AdminsPath = "E:\\OOPlab\\OOPProjectBusinessApplication\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\Admins.txt";
            string CostumersPath = "E:\\OOPlab\\OOPProjectBusinessApplication\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\Costumers.txt";
            string NotificationsPath = "E:\\OOPlab\\OOPProjectBusinessApplication\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\notifications.txt";
            string promoPath = "E:\\OOPlab\\OOPProjectBusinessApplication\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\PromoCodes.txt";
            string rentedCarsPath = "E:\\OOPlab\\OOPProjectBusinessApplication\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\RentedCars.txt";





            Console.ReadKey();



            int option = 0;
            PersonDL.readFromFile(AdminsPath);
            PersonDL.readFromFile(CostumersPath);
            CarDL.readFromCarsFile(carsPath);
            AdminDL.ReadNotificationsFromFile(NotificationsPath);

            AdminDL.ReadPromo(promoPath);
            CostumerDL.ReadReviews(reviewsPath);

            do
            {
                Console.Clear();
                MenuUI.header();
                option = MenuUI.menuForSignInOrSignUp();



                if (option == 1)      //       >>>>>>>   FOR SIGNUP  <<<<<<<
                {
                    PersonBL p = PersonUI.takeInputForUserWithRole();
                    PersonDL.AddIntoPersonList(p);
                    if (p != null)
                    {

                        PersonDL.storeIntoFile(CostumersPath, p);

                    }
                    else
                    {
                        MenuUI.PrintWarningMessage();
                    }



                }

                if (option == 2)    //       >>>>>>   FOR SIGN IN   <<<<<<<
                {

                    PersonBL p = PersonUI.takeInputForUserWithoutRole(usersPath);


                    string userRole = PersonBL.GetUserRole(p);

                    bool flag = PersonBL.SetUserRole(userRole, p);
                    if (flag)
                    {

                        PersonBL person = PersonBL.setUserRole(userRole);

                        PersonUI pUI = new PersonUI();
                        AdminBL a = new AdminBL(userRole);
                        PersonBL n = new PersonBL(userRole);
                        CostumerBL c = new CostumerBL();
                        if (userRole == "admin")
                        {
                            int value = MenuUI.adminMenu();


                            if (value == 1)
                            {
                                MenuUI.headerOfAddCars();

                                CarBL car = CarUI.AddCarsUI();

                                if (car != null)
                                {
                                    CarDL.addCarsIntoCarList(car);
                                    CarDL.storeIntoFile(carsPath, car);
                                }



                            }
                            if (value == 2)
                            {
                                n.headerForViewAllCars();
                                n.viewAllCars();

                            }
                            if (value == 3)
                            {

                                string name = CarUI.getCarNameForAvailability();
                                ;

                                if (CarBL.setCarName(name))
                                {
                                    n.isCarNameAvailable(name);
                                }
                                else
                                    MenuUI.PrintWarningMessage();


                            }
                            if (value == 4)
                            {
                                //MenuUI.headerOfModifyCar();
                                string name = CarUI.getCarNameForAvailability();
                                if (CarBL.setCarName(name))
                                {
                                    n.isCarNameAvailable(name);

                                    char check = CarUI.ActionUI();
                                    if (check == 'y')
                                    {
                                       char m = CarUI.ModifyCarUI();
                                        if (m == 'p' || m == 'P')
                                        {
                                           // n.ChangePrice();
                                        }





                                    }
                                    else
                                        MenuUI.PrintWarningMessage();


                                }
                            }
                            if (value == 5)
                            {
                                CarUI.CheckDocuments();
                                MenuUI.ContinueProcessing();

                            }
                            if (value == 6)
                            {
                                //MenuUI.headerOfSeeTakenCars();
                            }
                            if (value == 7)
                            {

                                Console.Clear();



                                pUI.viewUsers();
                                MenuUI.ContinueProcessing();


                            }
                            if (value == 8)
                            {
                                //check/view/see reviews
                            }
                            if (value == 9)
                            {
                                // MenuUI.headerOfNotifications();
                                string notF = AdminUI.AddNotifications();
                                AdminBL d = new AdminBL(notF);
                                if (AdminBL.setNotifications(notF))
                                {
                                    AdminDL.storeNotificationIntoFile(NotificationsPath, notF);
                                    AdminDL.AddIntoNotificationList(d);


                                }



                            }
                            if (value == 10)
                            {
                                // remove Car
                                string CarName = CarUI.getCarName();

                                if (CarBL.setCarName(CarName))
                                {
                                    n.isCarNameAvailable(CarName);
                                    char check = CarUI.ActionUI();
                                    if (check == 'y')
                                    {
                                        CarDL.removeCar(CarName);
                                        CarDL.StoreIntoFileAfterRemoving(carsPath);

                                    }
                                    if (check == 'n')
                                    {
                                        CarUI.Thanks();
                                    }
                                    if (check == '0')
                                    {
                                        MenuUI.PrintWarningMessage();
                                    }


                                }


                            }
                            if (value == 11)
                            {

                                pUI.ViewNotifications();
                                MenuUI.ContinueProcessing();
                            }
                            if (value == 12)
                            {
                                string promo = AdminUI.AddPromoCode();
                                if (promo != null)
                                {
                                    AdminDL.storePromoCodeInFile(promoPath, promo);
                                    AdminDL.AddPromoIntoList(promo);
                                }

                            }
                            if (value == 13)
                            {
                                break;
                            }



                        }
                        if (userRole == "costumer")
                        {
                            int value = MenuUI.costumerMenu();
                            if (value == 1)
                            {
                                //rent a car
                                MenuUI.headerOfRentACar();
                                string name = CostumerUI.getCarNameUI();
                                if (CarBL.setCarName(name))
                                {
                                    if (n.isCarNameAvailable(name))
                                    {
                                        double price = n.GetCarPrice(name);
                                        int days = CostumerUI.getDays();
                                        string promo = CostumerUI.getPromo();
                                        if (promo != null)
                                        {
                                            bool check = CostumerBL.checkIfPromoIsAvailable(promo);
                                            if (check)
                                            {

                                                double finalPrice = CostumerBL.PriceWithDiscount(days, price);
                                                CostumerUI.PrintFinalPrice(days, finalPrice);

                                            }
                                            else if (!check)
                                            {
                                                double finalPrice = CostumerBL.PriceWithoutDiscount(days, price);
                                                CostumerUI.PrintFinalPrice(days, finalPrice);
                                            }

                                            CostumerDL.storeRentedCars(rentedCarsPath, name, days, price);

                                            CostumerDL.AddIntoRentedCarsList(name);



                                        }
                                        else
                                            MenuUI.PrintWarningMessage();





                                    }
                                    else
                                    {
                                        MenuUI.notAvailable();
                                    }
                                }
                                else
                                    MenuUI.PrintWarningMessage();

                            }
                            if (value == 2)
                            {
                                string name = CarUI.getCarNameForAvailability();


                                if (CarBL.setCarName(name))
                                {
                                    n.isCarNameAvailable(name);
                                }
                                else
                                    MenuUI.PrintWarningMessage();
                            }
                            if (value == 3)
                            {
                                Console
                                    .Clear();
                                string name = CarUI.getCarNameForAvailability();
                                if (CarBL.setCarName(name))
                                {
                                    n.GetCarPrice(name);

                                }
                                else
                                    MenuUI.PrintWarningMessage();

                            }
                            if (value == 4)
                            {
                                n.headerForViewAllCars();
                                n.viewAllCars();
                            }

                            if (value == 5)
                            {
                                //feedbacks
                                string name = CostumerUI.getCarNameUI();
                                if (CarBL.setCarName(name))
                                {
                                    if (n.isCarNameAvailable(name))
                                    {
                                        string review = CostumerUI.giveReview();
                                        // add review in review file
                                        CostumerDL.storeReviewsIntoFile(reviewsPath, review, name);
                                        //add review in review list
                                        CostumerDL.addIntoReviewList(review);
                                    }
                                    else
                                    {
                                        MenuUI.notAvailable();
                                    }
                                }
                                else
                                    MenuUI.PrintWarningMessage();

                            }



                            if (value == 6)
                            {
                                //see notification
                                pUI.ViewNotifications();
                                MenuUI.ContinueProcessing();

                            }
                            if (value == 7)
                            {
                                break;
                            }

                        }




                        Console.ReadKey();


                    }
                }
            }

            while (option != 3);


            Console.ReadKey();


        }
    }
}
