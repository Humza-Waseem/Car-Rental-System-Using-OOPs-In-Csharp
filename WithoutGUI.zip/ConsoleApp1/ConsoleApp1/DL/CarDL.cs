﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;
using System.IO;

namespace ConsoleApp1.DL
{
    class CarDL
    {
        //   >>>>>>   List of CARS 
        public static List<CarBL> listOfCars = new List<CarBL>();

        //Funtion for adding carintoo list
        public static void addCarsIntoCarList(CarBL c)
        {
            listOfCars.Add(c);
           
        }
        public static void removeCarFromList(CarBL c)
        {
            listOfCars.Remove(c);
            Console.WriteLine
                ("Car removed successfully");
        }
        public static void storeIntoFile(string path, CarBL car)
        {
            StreamWriter f = new StreamWriter(path, true);
            //   f.WriteLine(car.CarName + "," + car.company + "," + car.price + "," + car.color);
            f.WriteLine(car.getCarName() + "," + car.getCompanyName() + "," + car.getPrice() + "," + car.getColorCar());
            f.Flush();
            f.Close();
            Console.WriteLine("succesfull written into file");
            Console.ReadKey();
            Console.WriteLine("Continue adding cars");
            Console.ReadKey();
        }

        public static void StoreIntoFileAfterRemoving(string path)
        {
            StreamWriter filevar = new StreamWriter(path);
            foreach (CarBL car in listOfCars)
            {
                filevar.WriteLine(car.getCarName() + "," + car.getCompanyName() + "," + car.getPrice() + "," + car.getColorCar());
                filevar.Flush();
            }
            Console.WriteLine("entered into remove store list");
            filevar.Close();
        }


        public static bool readFromCarsFile(string path)
        {
            StreamReader f = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = f.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');     //  List<string> listss = new List<string>();
                    string name = splittedRecord[0];                            // listss.Insert(1, name);
                    string company = splittedRecord[1];
                    double price = double.Parse(splittedRecord[2]);
                    string color = splittedRecord[3];

                    CarBL car = new CarBL(name, company, color, price);
                    if (car != null)
                    {
                        addCarsIntoCarList(car);
                    }
                }
                f.Close();
                return true;

            }
            else
            {
                return false;
            }


          
        }
        public static bool removeCar(string name)
        {
           
            foreach (CarBL car in listOfCars)
            {
                if (name == car.getCarName())
                {
                    removeCarFromList(car);
                    //listOfCars.RemoveAt(x);
                    
                    
                    return true;
                }
                else
                {
                    continue;
                }

            }
            return false;

        }

    }
    }

