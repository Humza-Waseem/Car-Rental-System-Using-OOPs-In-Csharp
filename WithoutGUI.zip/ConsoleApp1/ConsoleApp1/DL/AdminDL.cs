﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using ConsoleApp1.BL;
using ConsoleApp1.UI;


namespace ConsoleApp1.DL
{
    class AdminDL
    {
        public static List<AdminBL> notifications = new List<AdminBL>();
        public static List<string> promoCodes = new List<string>();



        public static void AddIntoNotificationList(AdminBL d)
        {
            notifications.Add(d);
            Console.WriteLine("entered notifications successfully in list after reading from file");
        }
        public static void AddPromoIntoList(string promo)
        {
            promoCodes.Add(promo);
        }
        public static void storeNotificationIntoFile(string path, string notification)
        {
            StreamWriter f = new StreamWriter(path, true);
            //   f.WriteLine(car.CarName + "," + car.company + "," + car.price + "," + car.color);
            f.WriteLine(notification);
            f.Flush();
            f.Close();
            Console.WriteLine("succesfull written  notification into file");
            Console.ReadKey();
            

        }
        public static void storePromoCodeInFile(string path, string code)
        {
            StreamWriter f = new StreamWriter(path, true);
          
            f.WriteLine(code);
            f.Flush();
            f.Close();
            Console.WriteLine("succesfull written  Promo into file");
            Console.ReadKey();


        }


        public static bool ReadNotificationsFromFile(string path)
        {
            


                StreamReader f = new StreamReader(path);
                string record;
                if (File.Exists(path))
                {
                    while ((record = f.ReadLine()) != null)
                    {
                    string[] splittedRecord = record.Split('.');
                    string notification =splittedRecord[0];

                    AdminBL a = new AdminBL(notification);
                    a.getNotifications(notification);
                        while (notifications.Count > 0)
                        {

                        AdminDL.AddIntoNotificationList( a);
                        }
                    }
                    f.Close();
                    return true;

                }
                else
                {
                    return false;
                }
            }

        public static bool ReadPromo(string path)
        {

            StreamReader f = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = f.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split('.');
                    string promo = splittedRecord[0];

                    AdminBL a = new AdminBL(promo);
                    a.gerPromo(promo);
                    while (promoCodes.Count > 0)
                    {

                        AdminDL.AddPromoIntoList(promo);
                    }
                }
                f.Close();
                return true;

            }
            else
            {
                return false;
            }
        }
        public static bool readFromFile(string path)
        {

            StreamReader f = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = f.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string name = splittedRecord[0];
                    string password = splittedRecord[1];
                    string role = (splittedRecord[2]);

                    PersonBL p = new PersonBL(name, password, role);
                    while (PersonDL.persons.Count > 0)
                    {

                        PersonDL.AddIntoPersonList(p);
                    }
                }
                f.Close();
                return true;

            }
            else
            {
                return false;
            }



        }
    }
}
