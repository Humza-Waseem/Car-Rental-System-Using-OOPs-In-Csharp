﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;
using ConsoleApp1.UI;
using System.IO;

namespace ConsoleApp1.DL
{
    class PersonDL

    {
       public static  List<PersonBL> persons = new List<PersonBL>();

        //Read data from person file
        //Write data to person file
        //sort data 
        //add data into list 
        //remove data from list

        public static void AddIntoPersonList(PersonBL p)
        {
            persons.Add(p);
           //Console.WriteLine("added to   person list successfully after taking sign UP ");
        }
        public static void storeIntoFile(string path, PersonBL s)
        {
            StreamWriter f = new StreamWriter(path, true);
            // f.WriteLine(s.name + "," + s.password + "," + s.role);
            f.WriteLine(s.getUserName() + "," + s.getPassword() + "," + s.getRole());
            f.Flush();
            f.Close();
            

            Console.ReadKey();
            Console.WriteLine("You can SIGN IN Now");
            Console.ReadKey();


        }
        public static bool readFromFile(string path)
        {
            StreamReader f = new StreamReader(path);
                string record;
            if (File.Exists(path))
            {
                while ((record = f.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string name = splittedRecord[0];
                    string password = splittedRecord[1];
                    string role = splittedRecord[2];
                    

                    PersonBL p = new PersonBL(name, password, role);

                    if (p != null)
                    {
                        AddIntoPersonList(p);
                    }




                }
                    f.Close();
                    return true;

                }
                else
                {
                    return false;
                }

            
           
        }
       

        public static void removeFromList(PersonBL p)
        {
            persons.Remove(p);
        }

       
    }
}
