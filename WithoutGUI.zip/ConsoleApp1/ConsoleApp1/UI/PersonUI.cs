﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 using ConsoleApp1.BL;
using ConsoleApp1.DL;

namespace ConsoleApp1.UI
{
    class PersonUI
    {
        public static void viewNOtificationsUI()
        {

        }


        public static PersonBL takeInputForUserWithoutRole(string userPath)
        {
            Console.WriteLine("ENTER USERNAME: ");
            string name = Console.ReadLine();


            Console.WriteLine("ENTER YOUR  PASSWORD: ");
            string password = Console.ReadLine();

            PersonBL p = new PersonBL(name, password);
            return p;

        }
       
        public static PersonBL takeInputForUserWithRole()
        {

            Console.WriteLine("Enter your name: ");
            string name = Console.ReadLine();
            
               
            Console.WriteLine("Enter New password: ");
            string password = Console.ReadLine();

            Console.WriteLine("CONFIRM YOUR PASSWORD : ");
            string secondPassword = Console.ReadLine();

            Console.WriteLine("Enter Your Role: ");
            string role = Console.ReadLine();

            if (PersonDL.persons.Count > 0)
            {
                bool flag = PersonBL.isUserNameAvailable(name);

                if (flag == true)
                {
                    Console.WriteLine("UserName is  Already Available");
                    Console.ReadKey();
                    return null;
                }
                else if (name != null && password != null && role != null && password == secondPassword && (role == "costumer" || role == "Costumer" || role == "COSTUMER"))
                {
                    PersonBL person = new PersonBL(name, password, role);

                    return person;

                }
                else if (role != "costumer" && role != "Costumer")
                {
                    Console.WriteLine("############################");
                    Console.WriteLine("INVALID ROLE TYPE !!!! ");
                    Console.WriteLine("Consider Changing the role !!!");
                    Console.WriteLine("############################");
                    Console.ReadKey();

                }

            }

      
            return null;

        }
        public   virtual void viewUsers()
        {
            int j = 1;
            foreach (PersonBL p in PersonDL.persons)
            {
                Console.WriteLine("{0}. Name>> {1}  \t\t\t Role>> {2} ", j, p.getUserName(), p.getRole());
                j++;
            }
        }
        public  void ViewNotifications()
        {

           
            int i = 1;
            
            foreach(AdminBL a in AdminDL.notifications)
            {
                Console.WriteLine("{0}. ==>> {1}",i,a.gerNOtification());
                i++;
                    
            }

        }


    }
}
