﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.UI

{
    class MenuUI
    {
        public static void header()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("         ********************************************");
            Console.WriteLine("         *                                          *  ");
            Console.WriteLine("         *   _____              _____         _     *  ");
            Console.WriteLine("         *  |     |  ___ ___   | __  |___ ___| |_   *  ");
            Console.WriteLine("         *  |       | .'|  _|  |    -| -_|   |  _|  *  ");
            Console.WriteLine("         *  |_____| |__,|_|    |__|__|___|_|_|_|    *  ");
            Console.WriteLine("         *                                          *  ");
            Console.WriteLine("         ********************************************");
        }

        public static int menuForSignInOrSignUp()
        {
            int option;
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1. Sign UP ");
            Console.WriteLine("2. Sign IN");
            Console.WriteLine("3. EXIt");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter your option :");
            option = int.Parse(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Magenta;

            return option;

        }
       
        public static int adminMenu()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("             *******************************************************************");
            Console.WriteLine("             *    _____ ____  _____ _____  _____    _____ _____ _____ _____    *");
            Console.WriteLine("             *   |  _  |    !|     |  |   |   | |  |     |   __|   | |  |  |   *");
            Console.WriteLine("             *   |     |  | || | | |  |   | | | |  | | | |   __| | | |  |  |   *");
            Console.WriteLine("             *   |__|__|____/|_|_|_|__|___|_|___|  |_|_|_|_____|_|___|_____|   *");
            Console.WriteLine("             *                                                                 *");
            Console.WriteLine("             *******************************************************************");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("[1]  Add cars");
            Console.WriteLine("[2]  View All Cars");
            Console.WriteLine("[3]  Check availability ");
            Console.WriteLine("[4]  Modify Car");
            Console.WriteLine("[5]  Check Documents");
            Console.WriteLine("[6]  See Taken Cars");
            Console.WriteLine("[7]  View Costumers");
            Console.WriteLine("[8]  Check Reviews");
            Console.WriteLine("[9]  ADD Notifications");
            Console.WriteLine("[10] Remove Car");
            Console.WriteLine("[11] View Notifications");
            Console.WriteLine("[12] ADD Promo Code");

            Console.WriteLine("13. EXIT");

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;

            int option;
            Console.WriteLine("Select any option:");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        public static int costumerMenu()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("         *******************************************************************");
            Console.WriteLine("         *                                                                 *");
            Console.WriteLine("         *      _____         _                        _____               *");
            Console.WriteLine("         *     |     |___ ___| |_ _ _ _____ ___ ___   |     |___ ___ _ _   *");
            Console.WriteLine("         *     |   --| . |_ -|  _| | |     | -_|  _|  | | | | -_|   | | |  *");
            Console.WriteLine("         *     |_____|___|___|_| |___|_|_|_|___|_|    |_|_|_|___|_|_|___|  *");
            Console.WriteLine("         *                                                                 *");
            Console.WriteLine("         *******************************************************************");
            Console.WriteLine();
            
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. Rent A Car");
            Console.WriteLine("" +
                "2. Check Availability");
            Console.WriteLine("3. Check Price");
            Console.WriteLine("4. View All Cars ");
            
            Console.WriteLine("5. Give FeedBack");
            
            Console.WriteLine("6. See Notifications/Updates");
            Console.WriteLine("7. EXIT");
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Select any option:");
            int option = int.Parse(Console.ReadLine());
            return option;
        }
        public static void headerOfAddCars()
        {

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("         *********************************************************");
            Console.WriteLine("         *                                                       *  ");
            Console.WriteLine("         *        _____ ____  ____     _____ _____ _____ _____   *  ");
            Console.WriteLine("         *       |  _  |    !|    !   |     |  _  | __  |   __|  *  ");
            Console.WriteLine("         *       |     |  |  |  |  |  |   --|     |    -|__   |  *  ");
            Console.WriteLine("         *       |__|__|____/|____/   |_____|__|__|__|__|_____|  *  ");
            Console.WriteLine("         *                                                       *  ");
            Console.WriteLine("         *********************************************************");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Magenta;
        }
        public static void headerOfViewAllCars()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("         *********************************************************");
            Console.WriteLine("         *                                                       *");
            Console.WriteLine("         *       _____ _              _____ _____ _____ _____    *");
            Console.WriteLine("         *      |  |  |_|___ _ _ _   |     |  _  | __  |   __|   *");
            Console.WriteLine("         *      |  |  | | -_| | | |  |   --|     |    -|__   |   *");
            Console.WriteLine("         *       !___/|_|___|_____|  |_____|__|__|__|__|_____|   *");
            Console.WriteLine("         *                                                       *");
            Console.WriteLine("         *********************************************************");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
        }
        public static void PrintWarningMessage()
        {
            Console.WriteLine("YOU TYPED INVALID OPTIONS");
            Console.WriteLine("CONSIDER TYPING RIGHT OPTIONS");
            Console.ReadKey();

        }
        public static void notAvailable()
        {
            Console.WriteLine
                ("Car not Available!!");
            Console
                .WriteLine("Sorry For Inconvinience!");

        }
       public static void headerForCheckAvailability()
        {

        }
     public static void ContinueProcessing()
        {
            Console.WriteLine("Press Any Key To Continue: ");
            Console.WriteLine();
        }
        public static void headerOfRentACar()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("******************************************************************");
            Console.WriteLine("*                                                                *");
            Console.WriteLine("*     _____ _____ _____ _____      _____    _____ _____ _____    *");
            Console.WriteLine("*    | __  |   __|   | |_   _|    |  _  |  |     |  _  | __  |   *");
            Console.WriteLine("*    |    -|   __| | | | | |      |     |  |   --|     |    -|   *");
            Console.WriteLine("*    |__|__|_____|_|___| |_|      |__|__|  |_____|__|__|__|__|   *");
            Console.WriteLine("*                                                                *");
            Console.WriteLine("******************************************************************");
            Console.ForegroundColor = ConsoleColor.Magenta;

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
        }

    }
}
