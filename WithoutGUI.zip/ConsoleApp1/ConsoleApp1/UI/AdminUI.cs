﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.DL;
using ConsoleApp1.BL;

namespace ConsoleApp1.UI
{
    class AdminUI
    {
        public static string  AddNotifications()
        { 
            Console.WriteLine("ENter any new Announcemen");
            string announcement = Console.ReadLine();
            
            return announcement;

           
        }
        public static string AddPromoCode()
        {
            Console.Write("Enter New Promo Code :");
            string promo = Console.ReadLine();
            if (AdminBL.setPromoCode(promo)) 
            {
                return promo;
            }
            return null;
        }

    }
}
