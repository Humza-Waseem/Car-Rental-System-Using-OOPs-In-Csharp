﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;
using ConsoleApp1.DL;

namespace ConsoleApp1.UI
{
    class CostumerUI
    {
        public static string getCarNameUI()
        {
            Console.WriteLine("Enter the Car Name: ");
            string name = Console.ReadLine();
            return name;        
        }
        public static int  getDays()
        {
            Console.WriteLine("For How many days You want to take the car ??");
            int days = int.Parse(Console.ReadLine());
            return days;

                
        }
        public static string getPromo()
        {
            Console.WriteLine("Enter Promo : ");
            string promo = Console.ReadLine();

            return promo;

                
        }
        public static string giveReview()
        {
            Console.WriteLine("Enter Review : ");
            string review = Console.ReadLine();
            if (CostumerBL.setReview(review))
            {
                return review;
            }
            return null;
        }
        public static void PrintFinalPrice(int days,double price)
        {
            Console.WriteLine("Final Price For {0} Day of Rent Will be {1}", days, price);
                
        }

    }
}
