﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;
using ConsoleApp1.DL;


namespace ConsoleApp1.UI
{
    class CarUI
    {

        public static void checkAvailabilty()
        {
            Console.WriteLine("Enter the Name of Car: ");
            string name = Console.ReadLine();
            CarBL.isCarNameAvailable(name);

        }
        public static void headerOfViewCars()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("*********************************************************");
            Console.WriteLine("*                                                       *");
            Console.WriteLine("*       _____ _              _____ _____ _____ _____    *");
            Console.WriteLine("*      |  |  |_|___ _ _ _   |     |  _  | __  |   __|   *");
            Console.WriteLine("*      |  |  | | -_| | | |  |   --|     |    -|__   |   *");
            Console.WriteLine("*       !___/|_|___|_____|  |_____|__|__|__|__|_____|   *");
            Console.WriteLine("*                                                       *");
            Console.WriteLine("*********************************************************");
            Console.ForegroundColor = ConsoleColor.Magenta;
        }
        public static void headerOfAddCars()
        {

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("*********************************************************");
            Console.WriteLine("*                                                       *  ");
            Console.WriteLine("*        _____ ____  ____     _____ _____ _____ _____   *  ");
            Console.WriteLine("*       |  _  |    !|    !   |     |  _  | __  |   __|  *  ");
            Console.WriteLine("*       |     |  |  |  |  |  |   --|     |    -|__   |  *  ");
            Console.WriteLine("*       |__|__|____/|____/   |_____|__|__|__|__|_____|  *  ");
            Console.WriteLine("*                                                       *  ");
            Console.WriteLine("*********************************************************");

            Console.ForegroundColor = ConsoleColor.Magenta;
        }
        public static CarBL AddCarsUI()
        {
            Console.WriteLine("Enter the NAME of Car: ");
            string cName = Console.ReadLine();

            Console.WriteLine("Enter the Name of Company: ");
            string company = Console.ReadLine();

            Console.WriteLine("Enter the PRICE for 1 Day Rent : ");
            int price = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the COLOR for Car :");
            string color = Console.ReadLine();

            bool flag = CarBL.setCar(cName, company, price, color);
            if (flag)
            {
                if (CarBL.listOfCars.Count <= 0)
                {
                    //for checking carName Availability
                    bool check = CarBL.isCarNameAvailable(cName);
                    //for checking ir carColor is same
                    bool var = CarBL.isCarColorSame(color);

                    //if both car name and color are available in the list then do not add New Car
                    if (check == true && var == true)
                    {
                        Console.WriteLine("Car Is Already Available");

                      

                        return null;
                    }
                    if (check == true && var == false)
                    {
                        CarBL car = new CarBL(cName, company, color, price);
                        return car;
                    }

                    CarBL ncar = new CarBL(cName, company, color, price);
                    return ncar;
                }
            }
            else if (!flag)
            {
                MenuUI.PrintWarningMessage();
            }
            return null;
        }
        public static string getCarNameForAvailability()
        {
            Console.WriteLine("Enter the Car Name : ");
            string name = Console.ReadLine();
            return name;

        }


        public static void CheckDocuments()

        {
            Console.Clear();
            Console.WriteLine("******************CHECK DOCUMENTS********************");

            char age;
            char license;
            Console.WriteLine("Is the COSTUMER above 18??   (y/n)");
            age = char.Parse(Console.ReadLine());

            Console.WriteLine("Does the COSTUMER possess a License??    (y/n)");
            license = char.Parse(Console.ReadLine());
            if ((age == 'y' || age == 'Y') && (license == 'y' || license == 'Y'))
            {
                // system("Color 0A");
                Console.WriteLine("______________________");
                Console.WriteLine("COSTUMER is ELEGIBLE !!");
                Console.WriteLine("______________________");
                Console.WriteLine("Press Any Key To Continue: ");
                Console.WriteLine();


            }
            else
            {
                // system("Color E4");
                Console.WriteLine("___________________________");
                Console.WriteLine("COSTUMER IS NOT ELIGIBLE !!");
                Console.WriteLine("___________________________");




            }

        }
        public static string getCarName()
        {
            Console.WriteLine("Enter the name of car you want to remove : ");
            string carName = Console.ReadLine();
            return carName;
        }
        public static char ModifyCarUI()
        {
            Console.WriteLine("What do you want to Modify. Press 'P' to change Price . Press 'C' to change Color . Press 'K' to change Company ");
            char modify = char.Parse(Console.ReadLine());
            return modify;

        }
        public static char ActionUI()
        {
            Console.WriteLine("Do You WantTo Proceed Your Action :   (y/n)  ==> "+"  ('y' for yes) and ('n' for no) ");
            char op = Char.Parse(Console.ReadLine());
            if(op == 'y' || op =='Y')
            {
                return 'y';
            }
            else if (op == 'n' || op == 'N')
            {
                return 'n';
            }
            return '0';
        }
        public static void Thanks()
        {
            Console.WriteLine("Thanks For YOur TIme , See You soon :)  <3");
        }

}
    }



