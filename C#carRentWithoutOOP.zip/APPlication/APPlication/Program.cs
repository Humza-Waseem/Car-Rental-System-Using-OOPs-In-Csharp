﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace APPlication
{
    class Program
    {
        //------>>>>   Paths for the storing data in the file   <<<<-------
        string usersPath = "E:\\CarRentalSystemC#\\APPlication\\APPlication\\UserData.txt";
        string carsPath = "E:\\CarRentalSystemC#\\APPlication\\APPlication\\CarData.txt";

        static void Main(string[] args)
        {
            //------>>>>   Paths for the storing data in the file   <<<<-------
            string usersPath = "E:\\CarRentalSystemC#\\APPlication\\APPlication\\UserData.txt";
            string carsPath = "E:\\CarRentalSystemC#\\APPlication\\APPlication\\CarData.txt";


            // name,role,and password arrays
            string[] roles = new string[5];
            string[] names = new string[5];
            string[] pass = new string[5];

            //carName, price and quantity arrays
            string[] carName = new string[5];
            int[] carPrice = new int[5];
            int[] carQuantity = new int[5];

            int carCount = 0;
            int usersCount = 1;
            int option = 4;



            MainLogo();




            string name;
            string role;
            string password;

            //----------->>>>>   Function for reading Data from file   <<<<<----------
            readUserData(names, pass, roles, usersCount, usersPath);

            option = MainMenu();

            if (option == 1)
            {
                Console.WriteLine("--------->>>>>>>   User SignUP   <<<<<<<-----------");
                Console.WriteLine();
                clearScreen();
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("Enter Your Name: ");
                name = Console.ReadLine();
                Console.WriteLine("Enter Your Role: ");
                role = Console.ReadLine();
                Console.WriteLine("Enter your Password: ");
                password = Console.ReadLine();

                SignUpUser(name, password, role, names, pass, roles, usersCount, usersPath);
            }
            if (option == 2)
            {
                Console.WriteLine("--------->>>>>>>   User SignIn   <<<<<<<-----------");
                Console.WriteLine();
                clearScreen();
               // Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("Enter Your Name: ");
                name = Console.ReadLine();
                Console.WriteLine("Enter Your Role: ");
                role = Console.ReadLine();
                Console.WriteLine("Enter your Password: ");
                password = Console.ReadLine();

                signIn(name, names, usersCount, role);
            }
            if (option == 3)
            {
                viewUsers(usersCount, names, pass);
            }
            Console.ReadKey();
        }



        static void MainLogo()
        {

            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("      *********************************************");
            Console.WriteLine("      *                                           *");
            Console.WriteLine("      *   _____              _____         _      *");
            Console.WriteLine("      *  |     |  ___ ___   | __  |___ ___| |_    *");
            Console.WriteLine("      *  |       | .'|  _|  |    -| -_|   |  _|   *");
            Console.WriteLine("      *  |_____| |__,|_|    |__|__|___|_|_|_|     *");
            Console.WriteLine("      *                                           *");
            Console.WriteLine("      ********************************************");



        }

        static int MainMenu()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;

            int option;
            Console.WriteLine("1.SIGN UP:");
            Console.WriteLine("2.SIGN IN");
            Console.WriteLine("3.VIEW USERS");
            Console.WriteLine("4.EXIT");
            Console.WriteLine("Enter your option:");
            option = int.Parse(Console.ReadLine());

            return option;

        }
        static void SignUpUser(string name, string password, string role, string[] names, string[] pass, string[] roles, int userCount, string userPath)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            bool decision = false;
            decision = isValidUsername(names, userCount, name);
            if (decision == true)
            {
                AssignUserToArray(name, password, role, names, pass, roles, userCount);
                storeUserInFile(name, password, role, names, pass, roles, userCount, userPath);



            }
            else if (decision == false)
            {
                Console.WriteLine("Username already exists");

            }
        }
        static void clearScreen()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            Console.Clear();
        }
        static bool isValidUsername(string[] names, int userCount, string name)
        {
            bool flag = true;
            for (int i = 0; i < userCount; i++)
            {
                if (names[i] == name)
                {

                    flag = false;
                    break;
                }
            }
            return flag;
        }
        static void AssignUserToArray(string name, string password, string role, string[] names, string[] pass, string[] roles, int userCount)
        {
            if (role == "admin" || role == "customer" || role == "ADMIN" || role == "Admin" || role == "CUSTOMER" || role == "Customer")
            {
                if (userCount <= 4)
                {
                    names[userCount] = name;
                    pass[userCount] = password;
                    roles[userCount] = role;
                    userCount++;
                }
                else
                {
                    clearScreen();
                    Console.WriteLine("User Limit Exceeded.");
                }
            }
            else
            {
                clearScreen();
                Console.WriteLine("Invalid User type");
            }
        }

        // function for reading user file for storing data in arrays
        static void readUserData(string[] names, string[] pass, string[] roles, int usersCount, string userPath)
        {
            StreamReader fp = new StreamReader(userPath);
            string record;
            while ((record = fp.ReadLine()) != null)
            {
                if (usersCount > 4)
                {
                    break;
                }
                names[usersCount] = parseData(record, 1);
                pass[usersCount] = parseData(record, 2);
                roles[usersCount] = parseData(record, 3);
                usersCount = usersCount + 1;
            }
            fp.Close();
        }
        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }

        static void viewUsers(int usersCount, string[] names, string[] pass)
        {
            clearScreen();

            // Console.BackgroundColor = ConsoleColor.White;
           /* Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("    ____________");
            Console.Write("\t\t");
            Console.WriteLine("____________");*/

            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Usernames");
            Console.Write("\t\t");
            Console.WriteLine("Passwords");

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("_____________");
            Console.Write("\t\t");
            Console.WriteLine("_______________");

            Console.ForegroundColor = ConsoleColor.Gray;
            for (int idx = 0; idx < usersCount; idx++)
            {
                Console.WriteLine(names[idx]);
                Console.WriteLine("\t\t\t");
                Console.WriteLine(pass[idx]);
                Console.WriteLine();

            }
            Console.WriteLine();


        }
        static void storeUserInFile(string name, string password, string role, string[] names, string[] pass, string[] roles, int userCount, string userPath)
        {
            StreamReader fileVariable = new StreamReader(userPath);
            while ((fileVariable.ReadLine() != null))
            {
                Console.Write(name);
                Console.Write(",");
                Console.Write(role);
                Console.Write(",");
                Console.WriteLine(password);
            }
        }
        static void signIn(string name, string[] names, int usersCount, string role)
        {
            bool decision = true;
            decision = isValidUsername(names, usersCount, name);
            if (decision == false)
            {
                Console.WriteLine("Username Already Exists");
            }
            if (decision == true)
            {
                if (role == "admin" || role == "ADMIN" || role == "Admin")
                {
                    int returnedValue1 = 0;
                    returnedValue1 = adminMenu(names, usersCount, name, role);
                    if(returnedValue1 == 1)
                    {

                    }
                    if (returnedValue1 == 2)
                    {

                    }
                    if (returnedValue1 == 3)
                    {

                    }

                  /*  if ( role != "admin" || role != "ADMIN" || role !="Admin")
                    {
                        Console.WriteLine("  ---->>> INVALID ROLE <<<----");
                        clearScreen();
                        //Main(args);
                    }*/
                }
                else if (role == "Costumer" || role == "COSTUMER" || role == "costumer")
                {
                    int returnedValue2 = 0;
                    returnedValue2 =  costumerMenu(names,usersCount,name,role);
                    
                        if (returnedValue2 == 1)
                        {

                        }
                        if (returnedValue2 == 2)
                        {

                        }
                        if (returnedValue2 == 3)
                        {

                        }
                     /*   Console.WriteLine("  ---->>> INVALID ROLE <<<----");
                        clearScreen();
                       // Main(args);
                     */
                    
                }
            }
        }

        static int adminMenu(string[] names, int usersCount, string name, string role)
        {
            clearScreen();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(" ******************************************************************");
            Console.WriteLine(" *    _____ ____  _____ _____  _____    _____ _____ _____ _____    *");
            Console.WriteLine(" *   |  _  |    !|     |  |   |   | |  |     |   __|   | |  |  |   *");
            Console.WriteLine(" *   |     |  | || | | |  |   | | | |  | | | |   __| | | |  |  |   *");
            Console.WriteLine(" *   |__|__|____/|_|_|_|__|___|_|___|  |_|_|_|_____|_|___|_____|   *");
            Console.WriteLine(" *                                                                 *");
            Console.WriteLine(" *******************************************************************");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. Add cars");
            Console.WriteLine("2. View Cars");
            Console.WriteLine("3. Check availability ");
            Console.WriteLine("4. Modify Car");
            Console.WriteLine("5. Check Documents");
            Console.WriteLine("6. Returning A Car");
            Console.WriteLine("7. EXIT");
            Console.WriteLine();

            string num;
            Console.WriteLine("Select any option:");
            num = Console.ReadLine();
            int option2 = int.Parse(num);
            return option2;
        }
        static int costumerMenu(string[] names,int usersCount, string name, string role)
        {
            clearScreen();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("*******************************************************************");
            Console.WriteLine("*                                                                 *");
            Console.WriteLine("*      _____         _                        _____               *");
            Console.WriteLine("*     |     |___ ___| |_ _ _ _____ ___ ___   |     |___ ___ _ _   *");
            Console.WriteLine("*     |   --| . |_ -|  _| | |     | -_|  _|  | | | | -_|   | | |  *");
            Console.WriteLine("*     |_____|___|___|_| |___|_|_|_|___|_|    |_|_|_|___|_|_|___|  *");
            Console.WriteLine("*                                                                 *");
            Console.WriteLine("*******************************************************************");

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. Rent A Car" );
            Console.WriteLine("2. Check Availability" );
            Console.WriteLine("3. Check Price" );
            Console.WriteLine("4. View Car " );
            Console.WriteLine("5. Compare Price" );
            Console.WriteLine("6. EXIT");
            Console.WriteLine();

            string num;
            Console.WriteLine("Select any option:");
            num = Console.ReadLine();
            int option2 = int.Parse(num);
            return option2;
        }
    }
}
